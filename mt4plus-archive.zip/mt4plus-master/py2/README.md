# mt4plus
一款将股市十年价格导入MT4的插件

python2原版
